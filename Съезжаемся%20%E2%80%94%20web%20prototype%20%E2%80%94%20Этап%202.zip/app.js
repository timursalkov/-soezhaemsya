
(() => {
  const qs = window.SOEZHAEMSYA_PROTOTYPE;
  const KEY = "soezhaemsya.prototype.v1";
  const state = loadState() || {
    name: "",
    current: 0,
    answers: {},
    started: false,
    completed: false,
    rankingDemo: {},
    demoIndex: 0
  };

  // The prototype intentionally contains only representative screens.
  // The production question data will be plugged in later without changing the UI engine.
  const demoScreens = [
    {kind:"question", qid:1},
    {kind:"question", qid:3},
    {kind:"question", qid:2},
    {kind:"question", qid:5},
    {kind:"ranking"},
    {kind:"question", qid:74}
  ];

  function loadState(){
    try { return JSON.parse(localStorage.getItem(KEY)); } catch(e) { return null; }
  }
  function save(){
    localStorage.setItem(KEY, JSON.stringify(state));
    setSaved();
  }
  function setSaved(){
    const el=document.querySelector("[data-saved]");
    if(el){ el.textContent="✓ Сохранено"; setTimeout(()=>{ if(el) el.textContent=""; },900); }
  }
  function esc(s){
    return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
  }
  function findQ(id){ return qs.find(q=>q.id===id); }
  function render(){
    const app=document.getElementById("app");
    if(!state.started){ renderStart(app); return; }
    if(state.completed){ renderCompletion(app); return; }
    renderDemo(app);
  }
  function renderStart(app){
    const hasResume = Object.keys(state.answers).length || state.rankingDemo && Object.keys(state.rankingDemo).length;
    app.innerHTML=`
      <section class="screen center-screen">
        <div class="start-card">
          <div class="brand-mark" aria-hidden="true"></div>
          <div class="kicker">Тест перед совместной жизнью</div>
          <h1>СЪЕЗЖАЕМСЯ</h1>
          <p class="subtitle">Рабочий мобильный прототип. Здесь проверяем удобство прохождения до переноса всех 89 заданий.</p>
          <div class="meta"><span class="pill">89 вопросов в полной версии</span><span class="pill">iPhone / Safari</span></div>
          <label class="helper" for="name">Имя</label>
          <input id="name" class="select" style="margin:7px 0 14px" value="${esc(state.name||"")}" placeholder="Введите имя" autocomplete="name">
          <button class="primary" id="startBtn">${hasResume ? "Продолжить прототип" : "Начать тест"}</button>
          ${hasResume ? `<div class="resume-card">Сохранённый прогресс найден. Ответы хранятся локально на этом устройстве.</div>` : ""}
        </div>
      </section>`;
    document.getElementById("name").addEventListener("input",e=>{state.name=e.target.value;save();});
    document.getElementById("startBtn").addEventListener("click",()=>{
      state.started=true; save(); render();
    });
  }
  function renderChrome(title, num, percent){
    return `<div class="topbar">
      <button class="icon-btn" id="backBtn" aria-label="Назад">‹</button>
      <div class="progress-label">${num ? num+" / 89" : "Прототип"}</div>
    </div>
    <div class="progress"><span style="width:${percent}%"></span></div>
    <div class="question-head">
      <div class="block-label">${title}</div>
    </div>`;
  }
  function renderDemo(app){
    const screen=demoScreens[state.demoIndex];
    const total=demoScreens.length;
    if(screen.kind==="ranking"){ renderRanking(app,total); return; }
    const q=findQ(screen.qid);
    if(!q) return;
    if(q.type==="single") renderSingle(app,q,total);
    if(q.type==="multi") renderMulti(app,q,total);
    if(q.type==="scale") renderScale(app,q,total);
    if(q.type==="text") renderText(app,q,total);
    if(q.type==="scenario") renderScenario(app,q,total);
  }
  function footer(disabled=false){
    return `<div class="bottom">
      <div class="saved" data-saved></div>
      <button class="primary" id="nextBtn" ${disabled?"disabled":""}>Далее →</button>
    </div>`;
  }
  function selected(qid){ return state.answers[qid]; }
  function optionsHtml(q, multi){
    const val=selected(q.id);
    return q.options.map((o,i)=>{
      const active=multi ? Array.isArray(val)&&val.includes(i) : val===i;
      return `<button type="button" class="option ${multi?"multi":""} ${active?"selected":""}" data-opt="${i}">${esc(o)}</button>`;
    }).join("");
  }
  function renderSingle(app,q,total){
    const val=selected(q.id);
    app.innerHTML=`<section class="screen">
      ${renderChrome(`БЛОК ${q.block} / 13`, q.id, (q.id/89)*100)}
      <div class="block-title">${esc(q.blockTitle)}</div>
      <h2 class="question">${esc(q.text)}</h2>
      <div class="option-list" style="margin-top:18px">${optionsHtml(q,false)}</div>
      ${footer(val===undefined)}
    </section>`;
    bindOptions(q,false);
    document.getElementById("nextBtn").onclick=next;
    document.getElementById("backBtn").onclick=back;
  }
  function renderMulti(app,q,total){
    const val=selected(q.id)||[];
    app.innerHTML=`<section class="screen">
      ${renderChrome(`БЛОК ${q.block} / 13`, q.id, (q.id/89)*100)}
      <div class="block-title">${esc(q.blockTitle)}</div>
      <h2 class="question">${esc(q.text)}</h2>
      <div class="option-list" style="margin-top:18px">${optionsHtml(q,true)}</div>
      <div class="counter">${val.length} / ${q.max} выбрано</div>
      ${footer(val.length===0)}
    </section>`;
    bindOptions(q,true);
    document.getElementById("nextBtn").onclick=next;
    document.getElementById("backBtn").onclick=back;
  }
  function renderScale(app,q,total){
    const val=selected(q.id);
    const value=val===undefined?5:val;
    app.innerHTML=`<section class="screen">
      ${renderChrome(`БЛОК ${q.block} / 13`, q.id, (q.id/89)*100)}
      <div class="block-title">${esc(q.blockTitle)}</div>
      <h2 class="question">${esc(q.text)}</h2>
      <div class="scale-wrap" style="margin-top:20px">
        <div class="scale-value" id="scaleValue">${value}</div>
        <input class="range" id="range" type="range" min="0" max="10" step="1" value="${value}" aria-label="Шкала от 0 до 10">
        <div class="scale-labels"><span>0<br>${esc(q.minLabel)}</span><span>10<br>${esc(q.maxLabel)}</span></div>
      </div>
      ${footer(false)}
    </section>`;
    document.getElementById("range").addEventListener("input",e=>{
      state.answers[q.id]=Number(e.target.value);
      document.getElementById("scaleValue").textContent=e.target.value;
      save();
    });
    document.getElementById("nextBtn").onclick=next;
    document.getElementById("backBtn").onclick=back;
  }
  function renderText(app,q,total){
    const val=selected(q.id)||"";
    app.innerHTML=`<section class="screen">
      ${renderChrome(`БЛОК ${q.block} / 13`, q.id, (q.id/89)*100)}
      <div class="block-title">${esc(q.blockTitle)}</div>
      <h2 class="question">${esc(q.text)}</h2>
      <textarea id="textAnswer" class="textarea" rows="${q.lines}" style="margin-top:20px" placeholder="Напиши свой ответ…">${esc(val)}</textarea>
      ${footer(false)}
    </section>`;
    const ta=document.getElementById("textAnswer");
    const autosize=()=>{ta.style.height="auto";ta.style.height=Math.max(116,ta.scrollHeight)+"px";};
    ta.addEventListener("input",()=>{state.answers[q.id]=ta.value;autosize();save();});
    autosize();
    document.getElementById("nextBtn").onclick=next;
    document.getElementById("backBtn").onclick=back;
  }
  function renderScenario(app,q,total){
    const val=selected(q.id)||{};
    const choice=val.choice;
    const scale=val.scale===undefined?5:val.scale;
    const text=val.text||"";
    app.innerHTML=`<section class="screen">
      ${renderChrome(`БЛОК ${q.block} / 13`, q.id, (q.id/89)*100)}
      <div class="scenario">
        <div class="scenario-tag">Ситуация ${q.id}</div>
        <h2 class="scenario-title">${esc(q.text)}</h2>
        <div class="subquestion">${esc(q.prompt)}</div>
        <div class="option-list">${q.options.map((o,i)=>`<button type="button" class="option ${choice===i?"selected":""}" data-opt="${i}">${esc(o)}</button>`).join("")}</div>
        <div class="subquestion">${esc(q.scaleLabel)}</div>
        <div class="scale-wrap">
          <div class="scale-value" id="scenarioScale">${scale}</div>
          <input class="range" id="scenarioRange" type="range" min="0" max="10" step="1" value="${scale}">
          <div class="scale-labels"><span>0<br>${esc(q.scaleMin)}</span><span>10<br>${esc(q.scaleMax)}</span></div>
        </div>
        <div class="subquestion">${esc(q.openLabel)}</div>
        <textarea id="scenarioText" class="textarea" rows="${q.lines}" placeholder="Напиши свой ответ…">${esc(text)}</textarea>
      </div>
      ${footer(choice===undefined)}
    </section>`;
    document.querySelectorAll("[data-opt]").forEach(b=>b.addEventListener("click",()=>{
      const i=Number(b.dataset.opt); const cur=state.answers[q.id]||{};
      state.answers[q.id]={...cur,choice:i}; save(); render();
    }));
    document.getElementById("scenarioRange").addEventListener("input",e=>{
      const cur=state.answers[q.id]||{}; state.answers[q.id]={...cur,scale:Number(e.target.value)};
      document.getElementById("scenarioScale").textContent=e.target.value; save();
    });
    document.getElementById("scenarioText").addEventListener("input",e=>{
      const cur=state.answers[q.id]||{}; state.answers[q.id]={...cur,text:e.target.value}; save();
    });
    document.getElementById("nextBtn").onclick=next;
    document.getElementById("backBtn").onclick=back;
  }
  function renderRanking(app,total){
    const options=["Спокойствие","Чистота и порядок","Личное пространство","Предсказуемость и договорённости","Забота и поддержка"];
    const vals=state.rankingDemo||{};
    const used=new Set(Object.values(vals).filter(v=>v!==""));
    const rows=options.map((o,i)=>{
      const current=vals[i]??"";
      const choices=options.map(x=>{
        const taken=used.has(x)&&x!==current;
        return `<option value="${esc(x)}" ${current===x?"selected":""} ${taken?"disabled":""}>${esc(x)}</option>`;
      }).join("");
      return `<div class="rank-row"><div class="rank-num">${i+1}</div><select class="select rank-select" data-rank="${i}"><option value="">Выбрать…</option>${choices}</select></div>`;
    }).join("");
    app.innerHTML=`<section class="screen">
      ${renderChrome("Демонстрация механики ranking", "", 70)}
      <div class="block-title">UI-прототип — не отдельное задание теста</div>
      <h2 class="question">Расставь варианты по важности.</h2>
      <p class="helper">В полной версии ranking будет подключён только там, где он предусмотрен утверждённым содержанием.</p>
      <div class="rank-list" style="margin-top:18px">${rows}</div>
      ${footer(false)}
    </section>`;
    document.querySelectorAll(".rank-select").forEach(s=>s.addEventListener("change",()=>{
      state.rankingDemo[s.dataset.rank]=s.value; save(); renderRanking(app,total);
    }));
    document.getElementById("nextBtn").onclick=next;
    document.getElementById("backBtn").onclick=back;
  }
  function bindOptions(q,multi){
    document.querySelectorAll("[data-opt]").forEach(btn=>btn.addEventListener("click",()=>{
      const i=Number(btn.dataset.opt);
      if(multi){
        let arr=Array.isArray(state.answers[q.id])?state.answers[q.id]:[];
        if(arr.includes(i)) arr=arr.filter(x=>x!==i);
        else if(arr.length<q.max) arr=[...arr,i];
        state.answers[q.id]=arr;
      } else state.answers[q.id]=i;
      save(); render();
    }));
  }
  function next(){
    if(state.demoIndex < demoScreens.length-1){ state.demoIndex++; save(); render(); }
    else { state.completed=true; save(); render(); }
    window.scrollTo({top:0,behavior:"smooth"});
  }
  function back(){
    if(state.demoIndex>0){state.demoIndex--;save();render();window.scrollTo({top:0,behavior:"smooth"});}
    else {state.started=false;save();render();}
  }
  function renderCompletion(app){
    const payload={
      test:"СЪЕЗЖАЕМСЯ",
      version:"prototype-1.0",
      participant:state.name||"",
      completed:true,
      prototypeScreens:demoScreens.length,
      answers:state.answers,
      rankingDemo:state.rankingDemo
    };
    app.innerHTML=`<section class="screen center-screen completion">
      <div class="completion-icon">✓</div>
      <h2>Прототип завершён</h2>
      <p>Все демонстрационные ответы сохранены локально. В полной версии здесь будет завершение теста из 89 заданий и экспорт ответов.</p>
      <div class="actions">
        <button class="primary" id="exportBtn">Скачать тестовые ответы</button>
        <button class="secondary" id="restartBtn">Пройти прототип заново</button>
      </div>
    </section>`;
    document.getElementById("exportBtn").onclick=()=>downloadJson(payload);
    document.getElementById("restartBtn").onclick=()=>{
      state.current=0;state.demoIndex=0;state.answers={};state.rankingDemo={};state.completed=false;state.started=true;save();render();
    };
  }
  function downloadJson(obj){
    const blob=new Blob([JSON.stringify(obj,null,2)],{type:"application/json"});
    const a=document.createElement("a");a.href=URL.createObjectURL(blob);
    a.download=`Съезжаемся — ${state.name||"прототип"} — ответы.json`;
    a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
  }
  render();
})();
